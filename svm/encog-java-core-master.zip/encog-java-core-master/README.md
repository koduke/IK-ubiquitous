[![Build Status](https://travis-ci.org/encog/encog-java-core.svg?branch=master)](https://travis-ci.org/encog/encog-java-core)

Encog 3.3

The following links will be helpful getting started with Encog.

Getting Started:

http://www.heatonresearch.com/wiki/Getting_Started

Important Links:

http://www.heatonresearch.com/encog